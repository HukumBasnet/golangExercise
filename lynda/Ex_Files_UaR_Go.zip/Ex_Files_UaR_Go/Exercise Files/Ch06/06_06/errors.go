package main

import (
	"fmt"
)

func main() {
	f, err := os.Open("filename.ext")

	// attendance := map[string]bool{
	// 	"Ann": true,
	// 	"Mike": true}
}
