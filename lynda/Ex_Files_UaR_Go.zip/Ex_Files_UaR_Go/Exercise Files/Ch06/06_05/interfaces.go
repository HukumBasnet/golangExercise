package main

import "fmt"

type Dog struct {
}

func main() {
	poodle := Dog{}
	fmt.Println(poodle)
}
