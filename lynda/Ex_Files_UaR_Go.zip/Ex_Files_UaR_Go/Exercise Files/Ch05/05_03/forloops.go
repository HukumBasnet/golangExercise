package main

import "fmt"

func main() {

	sum := 1
	fmt.Println("Sum:", sum)
	
	colors := []string{"Red", "Green", "Blue"}
	fmt.Println(colors)
	
}
