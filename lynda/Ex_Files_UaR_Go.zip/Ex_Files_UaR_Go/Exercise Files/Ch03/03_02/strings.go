package main

import (
	"fmt"
//	"strings"
)

func main() {
	
}
