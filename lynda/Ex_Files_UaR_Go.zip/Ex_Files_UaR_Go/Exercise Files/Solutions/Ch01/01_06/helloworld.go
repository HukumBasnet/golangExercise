package main

import (
	"fmt"
	"strings"
)

func main() {
	fmt.Println("Hello from Go!")
	fmt.Println(strings.ToUpper("Hello really loud!"))
}