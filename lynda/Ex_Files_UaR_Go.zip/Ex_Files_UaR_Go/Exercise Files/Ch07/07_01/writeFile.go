package main

import (
	"fmt"
)

func main() {
	
	content := "Hello from Go!"

}

func checkError(err error) {
	
}