package main

import (
	"fmt"
)

func main() {

}

func checkError(err error) {
	if err != nil {
		panic(err)
	}
}