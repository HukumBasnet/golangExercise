To install local assets:

* install NodeJs (https://nodejs.org)
* run `npm install` from the root directory of the project
- runt `grunt` from the root directory of the project

To run the application:

* run the following commands
 * `go install github.com/lss/webapp`
 * `src/webapp`

